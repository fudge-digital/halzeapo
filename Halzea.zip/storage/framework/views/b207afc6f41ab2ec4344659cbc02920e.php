<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Produksi - <?php echo e($po->no_spk); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        .header { font-size: 16px; font-weight: bold; margin-bottom: 20px; text-align:left; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; table-layout: fixed; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; word-wrap: break-word; }
        th { background-color: #f9f9f9; }
        .logo { width: 120px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <img src="<?php echo e(public_path('storage/images/HALZEA-LOGO.png')); ?>" alt="Logo" class="logo">
    </div>

    <p><strong>No SPK:</strong> <?php echo e($po->no_spk ?? '-'); ?></p>
    <p><strong>No Invoice:</strong> <?php echo e($po->no_invoice ?? '-'); ?></p>
    <p><strong>Status Produksi:</strong> <?php echo e(str_replace('_',' ', $po->production_status) ?? '-'); ?></p>
    <p><strong>Tanggal Kirim:</strong> <?php echo e(optional($po->tanggal_kirim)->format('d-m-Y') ?? '-'); ?></p>
    <p><strong>Alamat Pengiriman:</strong> <?php echo e($po->alamat_pengiriman ?? '-'); ?></p>

    <p style="text-align:right;"><strong>Customer:</strong> <?php echo e($po->customer); ?></p>

    <table>
        <colgroup>
            <col style="width: 15%">
            <col style="width: 15%">
            <col style="width: 15%">
            <col style="width: 10%">
            <col style="width: 20%">
            <col style="width: 15%">
            <col style="width: 10%">
        </colgroup>
        <thead>
            <tr>
                <th>Jenis Produk</th>
                <th>Kode Desain</th>
                <th>Bahan</th>
                <th>Ukuran</th>
                <th>Produksi</th>
                <th>Finishing-QC</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $po->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->jenis_produksi ?? 'N/A'); ?></td>
                <td><?php echo e($item->kode_desain ?? 'N/A'); ?></td>
                <td><?php echo e($item->bahan ?? 'N/A'); ?></td>
                <td><?php echo e($item->ukuran ?? 'N/A'); ?></td>
                <td>
                    <?php echo e($item->po_press ? 'Press: '.$item->po_press.' ' : ''); ?>

                    <?php echo e($item->po_print ? 'Print: '.$item->po_print.' ' : ''); ?>

                    <?php echo e($item->po_press_print ? 'Press/Print: '.$item->po_press_print : ''); ?>

                </td>
                <td>
                    <?php echo e($item->fqc_us ? $item->fqc_us.' ' : ''); ?>

                    <?php echo e($item->fqc_la ? $item->fqc_la.' ' : ''); ?>

                    <?php echo e($item->fqc_jt ? $item->fqc_jt : ''); ?>

                </td>
                <td style="text-align:center;"><?php echo e($item->quantity ?? 'N/A'); ?> pcs</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="6" style="text-align: right;">Total Quantity</th>
                <th style="text-align:center;">
                    <?php echo e($po->items->sum('quantity') ?? '0'); ?> pcs
                </th>
            </tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH C:\Users\faza adzima\Documents\PROJECT\halzpol\resources\views/pdf/produksi.blade.php ENDPATH**/ ?>