

<?php $__env->startSection('content'); ?>
<div class="max-w-8xl mx-auto p-6">
    <div class="mb-4">
        <p class="text-gray-700">
            Selamat datang, <span class="font-semibold"><?php echo e(auth()->user()->name); ?></span>
        </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-5 gap-6">
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">Purchase Order dibuat</h2>
            <p class="text-3xl font-bold text-blue-600"><?php echo e($totalPO ?? '0'); ?></p>
            <!-- <button href="<?php echo e(route('purchase-orders.index')); ?>" class="bg-sky-500 hover:bg-sky-600 mt-5 p-2 text-white text-sm rounded">Lihat Purchase Order</button> -->
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Pending oleh Finance</h2>
            <p class="text-3xl font-bold text-red-600"><?php echo e($pendingPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Approved oleh Finance</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($approvedPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Rejected oleh Finance</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($rejectedPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">Dalam Antrian Produksi</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($queuePO ?? '0'); ?></p>
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-5 gap-6 mt-6">
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Pending Produksi</h2>
            <p class="text-3xl font-bold text-yellow-500"><?php echo e($approvedFinancePOs ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Dalam Proses Produksi</h2>
            <p class="text-3xl font-bold text-yellow-500"><?php echo e($inprogPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Selesai Produksi</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($completedPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Siap Dikirim</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($readyshipPO ?? '0'); ?></p>
        </div>
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-200">
            <h2 class="text-lg font-semibold text-gray-800 mb-4">PO Terkirim</h2>
            <p class="text-3xl font-bold text-green-600"><?php echo e($shippedPO ?? '0'); ?></p>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\faza adzima\Documents\PROJECT\halzpol\resources\views/dashboard/index.blade.php ENDPATH**/ ?>